// engine3d.js — True Furnitures 3D Renderer (ES Module)

function project(x, y, z, rX, rY, cx, cy) {
  const x1 = x * Math.cos(rY) - z * Math.sin(rY);
  const z1 = x * Math.sin(rY) + z * Math.cos(rY);
  const y2 = y * Math.cos(rX) - z1 * Math.sin(rX);
  const z2 = y * Math.sin(rX) + z1 * Math.cos(rX);
  const s = 600 / (600 + z2 + 300);
  return { x: cx + x1 * s, y: cy + y2 * s, z: z2 };
}

function hexShift(hex, amt) {
  if (!hex || hex.length < 7) return hex;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const cl = v => Math.min(255, Math.max(0, v + amt));
  return '#' + [cl(r), cl(g), cl(b)].map(v => v.toString(16).padStart(2, '0')).join('');
}

function makeFaces(c) {
  return [hexShift(c,30), hexShift(c,-30), hexShift(c,-20), hexShift(c,20), hexShift(c,-40), hexShift(c,50)];
}

function drawCuboid(ctx, cx, cy, rX, rY, ox, oy, oz, w, h, d, colors) {
  const verts = [
    [ox-w/2,oy-h/2,oz-d/2],[ox+w/2,oy-h/2,oz-d/2],[ox+w/2,oy+h/2,oz-d/2],[ox-w/2,oy+h/2,oz-d/2],
    [ox-w/2,oy-h/2,oz+d/2],[ox+w/2,oy-h/2,oz+d/2],[ox+w/2,oy+h/2,oz+d/2],[ox-w/2,oy+h/2,oz+d/2],
  ].map(([x,y,z]) => project(x,y,z,rX,rY,cx,cy));
  const faces = [
    { idx:[4,5,6,7], c:colors[0] }, { idx:[0,1,2,3], c:colors[1] },
    { idx:[0,4,7,3], c:colors[2] }, { idx:[1,5,6,2], c:colors[3] },
    { idx:[3,2,6,7], c:colors[4] }, { idx:[0,1,5,4], c:colors[5] },
  ];
  faces.sort((a,b) => a.idx.reduce((s,i)=>s+verts[i].z,0) - b.idx.reduce((s,i)=>s+verts[i].z,0));
  faces.forEach(f => {
    ctx.beginPath();
    f.idx.forEach((i,k) => k===0 ? ctx.moveTo(verts[i].x,verts[i].y) : ctx.lineTo(verts[i].x,verts[i].y));
    ctx.closePath(); ctx.fillStyle=f.c; ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,0.06)'; ctx.lineWidth=0.5; ctx.stroke();
  });
}

export function drawSofa(ctx, cx, cy, rX, rY, color) {
  const c = color||'#8B6B4A', fc=makeFaces('#5C3D1E');
  const gc=['#C8A86B','#A8882B','#B8982B','#D8B87B','#A0800B','#E0C08B'];
  [[-60,40,0],[60,40,0],[-60,40,-40],[60,40,-40]].forEach(([x,y,z])=>drawCuboid(ctx,cx,cy,rX,rY,x,y,z,18,8,18,fc));
  drawCuboid(ctx,cx,cy,rX,rY,0,20,-10,180,30,80,makeFaces(c));
  drawCuboid(ctx,cx,cy,rX,rY,0,-28,-45,180,70,18,makeFaces(hexShift(c,-15)));
  drawCuboid(ctx,cx,cy,rX,rY,-100,10,-10,22,50,80,makeFaces(hexShift(c,-10)));
  drawCuboid(ctx,cx,cy,rX,rY,100,10,-10,22,50,80,makeFaces(hexShift(c,-10)));
  drawCuboid(ctx,cx,cy,rX,rY,-40,-22,-43,55,58,14,makeFaces(hexShift(c,10)));
  drawCuboid(ctx,cx,cy,rX,rY,40,-22,-43,55,58,14,makeFaces(hexShift(c,10)));
  drawCuboid(ctx,cx,cy,rX,rY,0,18,25,180,6,3,makeFaces(hexShift(c,-25)));
  drawCuboid(ctx,cx,cy,rX,rY,-100,10,-10,4,52,4,gc);
  drawCuboid(ctx,cx,cy,rX,rY,100,10,-10,4,52,4,gc);
}

export function drawAlmirah(ctx, cx, cy, rX, rY, color) {
  const c = color||'#6B4C2A';
  const gc=['#C8A86B','#A8882B','#B8982B','#D8B87B','#A0800B','#E0C08B'];
  drawCuboid(ctx,cx,cy,rX,rY,0,0,0,160,240,60,makeFaces(c));
  drawCuboid(ctx,cx,cy,rX,rY,-42,5,31,72,220,4,makeFaces(hexShift(c,25)));
  drawCuboid(ctx,cx,cy,rX,rY,42,5,31,72,220,4,makeFaces(hexShift(c,25)));
  drawCuboid(ctx,cx,cy,rX,rY,-12,5,34,6,18,4,gc);
  drawCuboid(ctx,cx,cy,rX,rY,12,5,34,6,18,4,gc);
  drawCuboid(ctx,cx,cy,rX,rY,0,-128,0,170,16,68,makeFaces(hexShift(c,-20)));
  drawCuboid(ctx,cx,cy,rX,rY,0,123,0,170,14,68,makeFaces(hexShift(c,-20)));
  drawCuboid(ctx,cx,cy,rX,rY,42,-30,31,70,90,2,['#B0C8D888','#A0B8C888','#90A8B888','#C0D8E888','#80A0B088','#D0E8F088']);
  drawCuboid(ctx,cx,cy,rX,rY,0,30,32,155,3,3,gc);
  drawCuboid(ctx,cx,cy,rX,rY,0,-120,0,165,4,64,gc);
}

export function drawBed(ctx, cx, cy, rX, rY, color) {
  const c = color||'#7A6A5A', fc=makeFaces('#5C3D1E');
  drawCuboid(ctx,cx,cy,rX,rY,0,10,10,200,25,130,makeFaces('#E8DDD0'));
  drawCuboid(ctx,cx,cy,rX,rY,0,28,10,205,10,135,fc);
  drawCuboid(ctx,cx,cy,rX,rY,0,-35,-54,200,90,20,makeFaces(c));
  drawCuboid(ctx,cx,cy,rX,rY,0,-35,-45,185,80,6,makeFaces(hexShift(c,20)));
  drawCuboid(ctx,cx,cy,rX,rY,0,15,70,200,40,14,makeFaces(c));
  drawCuboid(ctx,cx,cy,rX,rY,-55,-6,-20,85,20,40,makeFaces('#F0EAE0'));
  drawCuboid(ctx,cx,cy,rX,rY,55,-6,-20,85,20,40,makeFaces('#F0EAE0'));
  [[-95,-50],[-95,60],[95,-50],[95,60]].forEach(([lx,lz])=>drawCuboid(ctx,cx,cy,rX,rY,lx,40,lz,12,18,12,fc));
  drawCuboid(ctx,cx,cy,rX,rY,0,-2,25,195,10,80,makeFaces(hexShift(c,10)));
}

export function drawChair(ctx, cx, cy, rX, rY, color) {
  const c = color||'#C8A86B', fc=makeFaces('#5C3D1E');
  drawCuboid(ctx,cx,cy,rX,rY,0,0,0,100,18,90,makeFaces(c));
  drawCuboid(ctx,cx,cy,rX,rY,0,-45,-36,100,80,14,makeFaces(hexShift(c,-20)));
  drawCuboid(ctx,cx,cy,rX,rY,0,-45,-30,88,70,8,makeFaces(hexShift(c,15)));
  drawCuboid(ctx,cx,cy,rX,rY,-55,-10,0,14,12,80,fc);
  drawCuboid(ctx,cx,cy,rX,rY,55,-10,0,14,12,80,fc);
  [[-42,35],[-42,-35],[42,35],[42,-35]].forEach(([lx,lz])=>drawCuboid(ctx,cx,cy,rX,rY,lx,45,lz,10,80,10,fc));
  drawCuboid(ctx,cx,cy,rX,rY,0,55,0,80,6,6,fc);
}

export function parseOBJ(text) {
  const positions = [], faces = [];
  text.split('\n').forEach(line => {
    const p = line.trim().split(/\s+/);
    if (p[0]==='v') positions.push([+p[1],+p[2],+p[3]]);
    if (p[0]==='f') {
      const idxs = p.slice(1).map(s => parseInt(s.split('/')[0])-1);
      for (let i=1; i<idxs.length-1; i++) faces.push([idxs[0],idxs[i],idxs[i+1]]);
    }
  });
  return { positions, faces };
}

export function drawOBJModel(ctx, cx, cy, rX, rY, geo, color) {
  if (!geo||!geo.positions.length) return;
  const pts = geo.positions.map(([x,y,z]) => project(x*80,y*80,z*80,rX,rY,cx,cy));
  const tris = geo.faces.map(([a,b,c]) => ({ a,b,c, z:(pts[a].z+pts[b].z+pts[c].z)/3 }));
  tris.sort((a,b) => a.z-b.z);
  ctx.globalAlpha=0.88;
  tris.forEach(({a,b,c}) => {
    ctx.beginPath();
    ctx.moveTo(pts[a].x,pts[a].y); ctx.lineTo(pts[b].x,pts[b].y); ctx.lineTo(pts[c].x,pts[c].y);
    ctx.closePath(); ctx.fillStyle=color||'#8B6B4A'; ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,0.04)'; ctx.lineWidth=0.3; ctx.stroke();
  });
  ctx.globalAlpha=1;
}

export class RotController {
  constructor() {
    this.x=0.25; this.y=0.4; this.isDragging=false;
    this.lastX=0; this.lastY=0; this.autoAngle=0;
    this.autoSpeed=0.004; this.zoomScale=1;
  }
  attach(canvas) {
    const s = e => { this.isDragging=true; const src=e.touches?e.touches[0]:e; this.lastX=src.clientX; this.lastY=src.clientY; };
    const e2 = () => { this.isDragging=false; };
    const mv = e => {
      if (!this.isDragging) return;
      const src=e.touches?e.touches[0]:e;
      this.y += (src.clientX-this.lastX)*0.012;
      this.x += (src.clientY-this.lastY)*0.007;
      this.x=Math.max(-0.6,Math.min(0.9,this.x));
      this.lastX=src.clientX; this.lastY=src.clientY;
    };
    const wh = e => { e.preventDefault(); this.zoomScale=Math.min(1.8,Math.max(0.4,this.zoomScale-e.deltaY*0.001)); };
    canvas.addEventListener('mousedown',s);
    canvas.addEventListener('touchstart',s,{passive:true});
    window.addEventListener('mouseup',e2);
    window.addEventListener('touchend',e2);
    window.addEventListener('mousemove',mv);
    window.addEventListener('touchmove',mv,{passive:true});
    canvas.addEventListener('wheel',wh,{passive:false});
    return () => {
      canvas.removeEventListener('mousedown',s);
      canvas.removeEventListener('touchstart',s);
      window.removeEventListener('mouseup',e2);
      window.removeEventListener('touchend',e2);
      window.removeEventListener('mousemove',mv);
      window.removeEventListener('touchmove',mv);
      canvas.removeEventListener('wheel',wh);
    };
  }
  get rotY() { return this.y + this.autoAngle; }
  tick() { if (!this.isDragging) this.autoAngle += this.autoSpeed; }
}

export function renderCanvas(canvas, rot, drawFn) {
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const pr = window.devicePixelRatio||1;
  const nw = canvas.offsetWidth*pr, nh = canvas.offsetHeight*pr;
  if (canvas.width!==nw || canvas.height!==nh) { canvas.width=nw; canvas.height=nh; }
  const W=canvas.offsetWidth, H=canvas.offsetHeight;
  ctx.setTransform(pr,0,0,pr,0,0);
  ctx.clearRect(0,0,W,H);
  rot.tick();
  const sc=rot.zoomScale||1;
  ctx.save();
  ctx.translate(W/2,H/2); ctx.scale(sc,sc); ctx.translate(-W/2,-H/2);
  drawFn(ctx,W/2,H/2+20,rot.x,rot.rotY);
  ctx.restore();
}
